import React from 'react';

/**
 * Loader displays a pair of spinning rings while the simulation is idle.  The
 * second ring spins in the reverse direction using inline style to override
 * the default animation direction.
 */
const Loader = () => (
  <div className="fixed inset-0 flex items-center justify-center bg-white/70 dark:bg-black/70 z-50 pointer-events-none">
    <div className="relative w-24 h-24">
      <div className="absolute inset-0 border-4 border-primary border-dashed rounded-full animate-spin"></div>
      <div
        className="absolute inset-2 border-4 border-secondary border-dashed rounded-full animate-spin"
        style={{ animationDirection: 'reverse' }}
      ></div>
    </div>
  </div>
);

export default Loader;