import React from 'react';

/**
 * TheoryTab presents concise theoretical explanations accompanying the
 * experiments.  Explanations are intentionally brief to encourage learners
 * to interact with the simulations and explore further.
 */
const TheoryTab = () => (
  <div className="p-4 bg-card-light dark:bg-card-dark rounded-lg shadow">
    <h2 className="text-lg font-semibold mb-2">Theory</h2>
    <p className="text-sm leading-relaxed">
      Fluid mechanics is the study of fluids (liquids and gases) in motion or at
      rest. Understanding how fluids behave under various conditions helps
      engineers design pumps, turbines, pipelines and more. Use the simulation
      controls to change parameters like flow velocity, viscosity and pipe
      diameter. Observe how the velocity profile and viscous forces vary in
      real time.
    </p>
    <ul className="mt-4 list-disc list-inside space-y-1">
      <li>
        <strong>Bernoulli's theorem:</strong> relates pressure, velocity and
        height in a moving fluid.
      </li>
      <li>
        <strong>Reynolds number:</strong> determines whether flow is laminar or
        turbulent.
      </li>
      <li>
        <strong>Continuity equation:</strong> mass conservation in fluid flow
        (Q = V × A).
      </li>
    </ul>
  </div>
);

export default TheoryTab;