/**
 * Utilities for exporting simulation data to CSV and JSON formats.  The
 * functions dynamically create an anchor element and trigger a download.
 */
export const exportCSV = (data, filename = 'data') => {
  const header = ['time', 'velocity', 'viscosity'];
  const rows = data.map(row => [new Date(row.time).toISOString(), row.velocity, row.viscosity]);
  const csv = [header, ...rows].map(e => e.join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

export const exportJSON = (data, filename = 'data') => {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `${filename}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};