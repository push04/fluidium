import React from 'react';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import SimulationArea from './components/SimulationArea';
import ControlPanel from './components/ControlPanel';
import GraphPanel from './components/GraphPanel';
import DataTable from './components/DataTable';
import TheoryTab from './components/TheoryTab';
import QuizModal from './components/QuizModal';
import Loader from './components/Loader';
import { useAppContext } from './context/AppContext';

/**
 * The root component orchestrating layout and conditional display of the loader.
 */
const App = () => {
  const { isRunning } = useAppContext();
  return (
    <div className="h-screen flex flex-col">
      <Navbar />
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar for large screens */}
        <Sidebar />
        {/* Main content area */}
        <main className="flex-1 p-4 overflow-y-auto bg-background-light dark:bg-background-dark transition-colors">
          {/* Simulation and controls */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            <SimulationArea />
            <div className="space-y-4">
              <ControlPanel />
              <GraphPanel />
            </div>
          </div>
          {/* Data table and theory section */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 mt-4">
            <DataTable />
            <TheoryTab />
          </div>
        </main>
      </div>
      {/* Persistent quiz button and modal */}
      <QuizModal />
      {/* Loader overlay appears when simulation is not running */}
      {!isRunning && <Loader />}
    </div>
  );
};

export default App;