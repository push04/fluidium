import React, { createContext, useContext, useState, useEffect } from 'react';

/**
 * Application context providing global state for theme toggling, simulation control
 * and data management.  Other components can consume this context to read or
 * modify state without prop drilling.
 */
const AppContext = createContext();

export const AppProvider = ({ children }) => {
  // Persist the preferred theme in localStorage so the app remembers across reloads.
  const [theme, setTheme] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') || 'light';
    }
    return 'light';
  });

  const [isRunning, setIsRunning] = useState(false);
  // Simulation parameters controlling the experiment.  These can be extended.
  const [parameters, setParameters] = useState({
    flowVelocity: 1.0,
    viscosity: 1.0,
    pipeDiameter: 1.0,
  });
  // Raw data collected from the simulation over time.
  const [data, setData] = useState([]);
  // A separate array for charting so we can transform as needed without affecting raw data.
  const [chartData, setChartData] = useState([]);

  // Update the root element’s class whenever the theme changes.
  useEffect(() => {
    document.documentElement.classList.remove('light', 'dark');
    document.documentElement.classList.add(theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
  const updateParameter = (name, value) => setParameters(prev => ({ ...prev, [name]: value }));

  const startSimulation = () => {
    setIsRunning(true);
    setData([]);
    setChartData([]);
  };
  const pauseSimulation = () => setIsRunning(false);
  const resetSimulation = () => {
    setIsRunning(false);
    setData([]);
    setChartData([]);
  };
  // Append a new data point; typically called by the SimulationArea at each tick.
  const addDataPoint = (point) => {
    setData(prev => [...prev, point]);
    setChartData(prev => [...prev, { ...point }]);
  };

  const value = {
    theme,
    toggleTheme,
    isRunning,
    startSimulation,
    pauseSimulation,
    resetSimulation,
    parameters,
    updateParameter,
    data,
    chartData,
    addDataPoint,
  };
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useAppContext = () => useContext(AppContext);